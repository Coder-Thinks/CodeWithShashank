export class stateModel {
    stateId?:number;
    stateName="";
}