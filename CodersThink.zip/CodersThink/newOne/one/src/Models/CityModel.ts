export class cityModel {
    cityId?:number;
    cityName="";
}