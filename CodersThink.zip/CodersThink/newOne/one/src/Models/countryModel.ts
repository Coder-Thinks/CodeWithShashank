export class countryModel {
    countryId?:number;
    countryName="";
}